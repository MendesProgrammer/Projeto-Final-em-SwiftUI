//
//  projeto_final01App.swift
//  projeto_final01
//
//  Created by Turma01-8 on 26/02/25.
//

import SwiftUI

@main
struct projeto_final01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
