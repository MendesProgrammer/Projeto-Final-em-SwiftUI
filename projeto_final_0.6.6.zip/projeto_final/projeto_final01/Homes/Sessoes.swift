//
//  Sessoes.swift
//  projeto_final01
//
//  Created by Turma01-8 on 27/02/25.
//

import SwiftUI

struct Sessoes: View {
    @State var hist : Bool = false
    var body: some View {
        NavigationStack{
            ZStack {
                Color.cinza
                VStack {
                    VStack {
                        HStack {
                            Text("Minhas sessões")
                                .font(.title)
                                .foregroundStyle(.white)
                                .padding(.top, 50)
                        } // Fechamento do HStack
                        .frame(maxWidth: .infinity, maxHeight: 120)
                        .background(.azul)
                        
                        HStack {
                            Text("Proximas sessões")
                                .foregroundStyle(.azul)
                            
                                .frame(width: 200, height: 30)
                                .underline()
                            
                            HStack{
                                Text("Histórico")
                                    .foregroundStyle(.black)
                                    .underline()
                                    .frame(width: 200, height: 30)
                            }
                            .onTapGesture {
                                hist = true
                            }
                            .sheet(isPresented: $hist, content: {
                                Historico()
                            })

                            } // Fechamento do HStack
                        
                                                
                    } // Fechamento do VStack
                    
                    ///Spacer()
                    
                    VStack {
                        Image(.logoufu)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                        Text("Não há sessões agendadas")
                            .foregroundStyle(.azul)
                            .font(.title2)
                            .fontWeight(.medium)
                            .padding(.top, 30)

                    } // Fechamento do VStack
                    .frame(width: 300, height: 500)
                    .padding()
                    Spacer()

                } // Fechamento do VStack
                .ignoresSafeArea()
            } // Fechamento do VStack
        }
        .accentColor(.white)
    }
}

#Preview {
    Sessoes()
}
