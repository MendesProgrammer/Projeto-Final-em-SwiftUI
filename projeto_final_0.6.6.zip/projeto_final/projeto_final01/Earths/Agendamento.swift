//
//  Agendamento.swift
//  projeto_final01
//
//  Created by Turma01-8 on 10/03/25.
//

import SwiftUI

struct Agendamento: View {
    var psicologo : Psicologos
    var body: some View {
        ZStack {
            Color.cinza
                .edgesIgnoringSafeArea(.top)
            VStack {
                Text("Agendamento")
                    .font(.title)
                    .frame(maxWidth: .infinity, maxHeight: 70)
                    .background(.azul)
                    .foregroundStyle(.white)
                Spacer()
                VStack{
                    AsyncImage(url: URL(string: psicologo.foto)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray
                    }
                    .frame(width: 100, height: 100)
                    .padding()
                    VStack(alignment: .leading){
                        Text(psicologo.nome)
                            .font(.system(size:22))
                        Text(psicologo.cidade)
                        Text(psicologo.especialidade)
                        Text(psicologo.preco)
                    }
                    
                    Text("Escolha um horário da sessão")
                    
                    
                    
                } // Fechamento do VStack
                .frame(width: 350, height: 300)
                .background(.white)
                .cornerRadius(15)
                
                Spacer()
                
                Button("Agendar"){
                    
                }
                .foregroundStyle(.white)
                .frame(width: 350, height: 50)
                .background(.azul)
                .cornerRadius(15)
                
                Spacer()
            } // Fechamento do VStack
        } // Fechamento do ZStack
    }
}

#Preview {
    Agendamento(psicologo: Psicologos(nome: "teste", cidade: "teste", endereco: "teste", modalidade: "teste", especialidade: "teste", experiencia: "", horarioAtendimento: "", contato: "", foto: "teste", preco: ""))
}

