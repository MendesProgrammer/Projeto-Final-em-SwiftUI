//
//  MeusPlanos.swift
//  projeto_final01
//
//  Created by Turma01-8 on 12/03/25.
//

import SwiftUI

struct MeusPlanos: View {
    var body: some View {
        ZStack {
            Color.cinza
            VStack {
                VStack {
                    HStack{
                        Text("Meus Planos")
                            .foregroundStyle(.white)
                            .font(.title)
                            .fontWeight(.medium)
                            .foregroundColor(.black)
                            .padding(.top, 50)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: 120)
                .background(Color.azul)
//                    .cornerRadius(30.0)
                .ignoresSafeArea()
                Spacer()
            }
            VStack{
                Image(.logoufu)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                Text("Não há nenhum plano feito")
                    .foregroundStyle(.azul)
                    .font(.title2)
                    .fontWeight(.medium)
                    .padding(.top, 30)
            }
        } // Fechamento do ZStack
    }
}

#Preview {
    MeusPlanos()
}
