//
//  Agendamento.swift
//  projeto_final01
//
//  Created by Turma01-8 on 10/03/25.
//

import SwiftUI

struct Agendamento: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Agendamento()
}
