//
//  Call.swift
//  projeto_final01
//
//  Created by Turma01-8 on 26/02/25.
//

import SwiftUI

struct Call: View {
    var body: some View {
        ZStack {
            Color.azul
                .edgesIgnoringSafeArea(.top)
            Text("Call")
        } // Fechamento do ZStack
    }
}

#Preview {
    Call()
}
