//
//  planos_acessiveis.swift
//  projeto_final01
//
//  Created by Turma01-8 on 27/02/25.
//

import SwiftUI

struct planos_acessiveis: View {
    var body: some View {
        ZStack {
            Color.azul
                .edgesIgnoringSafeArea(.top)
            Text("Planos acessiveis")
        } // Fechamento do ZStack
    }
}

#Preview {
    planos_acessiveis()
}
