//
//  AgendarSessao.swift
//  projeto_final01
//
//  Created by Turma01-8 on 27/02/25.
//

import SwiftUI

struct AgendarSessao: View {
    var body: some View {
        ZStack {
            Color.azul
                .edgesIgnoringSafeArea(.top)
            Text("Agendar sessao")
        } // Fechamento do ZStack

    }
}

#Preview {
    AgendarSessao()
}
