//
//  Sessoes.swift
//  projeto_final01
//
//  Created by Turma01-8 on 27/02/25.
//

import SwiftUI

struct Sessoes: View {
    var body: some View {
        NavigationStack{
            ZStack {
                Color.azul
                    .edgesIgnoringSafeArea(.top)
                Text("Sessoes")
            } // Fechamento do ZStack
        }
    }
}

#Preview {
    Sessoes()
}
