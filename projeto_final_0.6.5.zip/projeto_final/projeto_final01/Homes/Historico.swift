//
//  Historico.swift
//  projeto_final01
//
//  Created by Turma01-8 on 12/03/25.
//

import SwiftUI

struct Historico: View {
    var body: some View {
//        NavigationStack{
            ZStack {
                Color.cinza
                    .edgesIgnoringSafeArea(.top)
                VStack {
                    VStack {
                        HStack {
                            Text("Minhas sessões")
                                .font(.title)
                                .foregroundStyle(.white)
                                .padding(.top, 50)
                        } // Fechamento do HStack
                        .frame(maxWidth: .infinity, maxHeight: 120)
                        .background(.azul)
                        
                        
                        HStack {
                                Text("Proximas sessões")
                                    .foregroundStyle(.black)
                                    .frame(width: 200, height: 30)
                                    .underline()
                            
                            Text("Histórico")
                                .foregroundStyle(.azul)
                                .underline()
                                .frame(width: 200, height: 30)
                        } // Fechamento do HStack
                    }
                    
                    VStack {
                        Image(.logoufu)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                        Text("Não há histórico")
                            .foregroundStyle(.azul)
                            .font(.title2)
                            .fontWeight(.medium)
                            .padding(.top, 30)
                        
                    } // Fechamento do VStack
                    .frame(width: 300, height: 500)
                    .padding()
                    Spacer()
                    
                } // Fechamento do VStack
                .ignoresSafeArea()
            }
//        }
//        .accentColor(.white)
    }
}

#Preview {
    Historico()
}
