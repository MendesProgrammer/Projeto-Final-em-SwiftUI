import SwiftUI

struct Chat: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color.cinza
                VStack {
                    VStack {
                        HStack{
                            Text("Meus Chats")
                                .foregroundStyle(.white)
                                .font(.title)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                                .padding(.top, 50)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: 120)
                    .background(Color.azul)
//                    .cornerRadius(30.0)
                    .ignoresSafeArea()
                    Spacer()
                }
                VStack{
                    Image(.logoufu)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                    Text("Não há nenhum chat")
                        .foregroundStyle(.azul)
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.top, 30)
                }
            }
        }
    }
}

#Preview {
    Chat()
}
