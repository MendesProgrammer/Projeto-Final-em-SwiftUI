//
//  Filtrar.swift
//  projeto_final01
//
//  Created by Turma01-8 on 10/03/25.
//

import SwiftUI

struct Filtrar: View {
    let contacts = [
          20,
          150,
          200
      ]
      
      @State private var selection: Int?
      @Environment(\.dismiss) var dismiss
      @StateObject var vm : SosUfuPsicologos
    
      var body: some View {
          NavigationView {
              VStack {
                  List(contacts, id: \.self, selection: $selection) { contact in

                      Text("\(contact)")
                  }
                  Text("\(selection ?? 0)")
                  
                  
                  Spacer()
                  
                  
                  Button("Filtrar"){
                      vm.filter(preco: selection! )
                      dismiss()
                  }
              }
          }
      }
}


struct SpecialButton_Preview: PreviewProvider {
    static var previews: some View {
        @StateObject var vm = SosUfuPsicologos()
        
        Filtrar(vm: vm)
    }
}
