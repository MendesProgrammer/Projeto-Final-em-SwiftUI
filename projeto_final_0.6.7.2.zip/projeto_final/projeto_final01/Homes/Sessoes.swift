//
//  Sessoes.swift
//  projeto_final01
//
//  Created by Turma01-8 on 27/02/25.
//

import SwiftUI

struct Sessoes: View {
    var body: some View {
        NavigationStack{
            VStack {
                HStack {
                    Text("Minhas sessões")
                        .font(.title)
                        .foregroundStyle(.white)
                } // Fechamento do HStack
                .frame(maxWidth: .infinity, maxHeight: 200)
                .background(.azul)
                .cornerRadius(10)
                
                HStack {
                    Text("Proximas sessões")
                        .foregroundStyle(.azul)
                    
                        .frame(width: 200, height: 30)
                        .underline()
                    
                    NavigationLink(destination: Historico()){
                        Text("Histórico")
                            .underline()
                            .frame(width: 200, height: 30)
                        } // Fechamento do HStack
                    } // Fechamento do Navigation
                
                Spacer()
                
            } // Fechamento do VStack
            .ignoresSafeArea()
        }
        .accentColor(.white)
    }
}

#Preview {
    Sessoes()
}
