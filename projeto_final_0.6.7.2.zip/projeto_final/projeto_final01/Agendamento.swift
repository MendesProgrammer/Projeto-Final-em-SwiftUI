//
//  Agendamento.swift
//  projeto_final01
//
//  Created by Turma01-8 on 10/03/25.
//

import SwiftUI

struct Agendamento: View {
    var body: some View {
        ZStack {
            Color.azul
                .edgesIgnoringSafeArea(.top)
        }
    }
}

#Preview {
    Agendamento()
}
